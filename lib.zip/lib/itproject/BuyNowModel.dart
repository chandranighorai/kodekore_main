class BuyNowModel {
  String itprojtAddedId;
  String userId;
  String itProjId;
  String projectAmount;
  String receivedAmount;
  String applicationStatus;
  String paymentStatus;
  String paymentMode;
  BuyNowModel(
      {this.itprojtAddedId,
      this.userId,
      this.itProjId,
      this.projectAmount,
      this.receivedAmount,
      this.applicationStatus,
      this.paymentStatus,
      this.paymentMode});
}
